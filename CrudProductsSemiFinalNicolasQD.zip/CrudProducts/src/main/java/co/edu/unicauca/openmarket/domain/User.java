package co.edu.unicauca.openmarket.domain;

/**
 *
 * @author Libardo Pantoja, Julio A. Hurtado
 */
class User {
    private Long userId;
    private String firstName;
    private String lastName;
    //Demas atributos

}
