/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unicauca.openmarket.domain.service;

import co.edu.unicauca.openmarket.access.IProductRepository;
import co.edu.unicauca.openmarket.access.ProductRepository;
import co.edu.unicauca.openmarket.domain.Category;

/**
 *
 * @author juand
 */
public class CategoryService {
    private IProductRepository repository;
    public boolean addCategory (Category nuevo){
    return repository.saveCategory (nuevo);
        }

    public void setRepository(ProductRepository productRepository) {
        repository= productRepository;
    }
    
}
