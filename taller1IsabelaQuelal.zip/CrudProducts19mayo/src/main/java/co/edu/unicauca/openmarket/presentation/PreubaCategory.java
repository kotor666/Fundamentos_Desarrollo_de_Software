/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.unicauca.openmarket.presentation;

import co.edu.unicauca.openmarket.access.ProductRepository;
import co.edu.unicauca.openmarket.domain.Category;
import co.edu.unicauca.openmarket.domain.service.CategoryService;

/**
 *
 * @author juand
 */
public class PreubaCategory {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Category category = new Category(); 
        category.setName("Oficina");
        CategoryService service = new CategoryService ();
        service.setRepository (new ProductRepository());
        service.addCategory(category);
        
    }
    
}
