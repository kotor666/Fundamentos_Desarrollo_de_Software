package co.edu.unicauca.openmarket.domain;

/**
 *
 * @author
 */
class User {
    private Long userId;
    private String firstName;
    private String lastName;
    //Demas atributos

}
