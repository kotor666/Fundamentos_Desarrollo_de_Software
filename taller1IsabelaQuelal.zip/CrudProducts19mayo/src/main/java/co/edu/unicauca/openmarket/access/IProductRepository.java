
package co.edu.unicauca.openmarket.access;

import co.edu.unicauca.openmarket.domain.Category;
import co.edu.unicauca.openmarket.domain.Product;
import java.util.List;

/**
 *
 * @author 
 */
public interface IProductRepository {
    boolean save(Product newProduct);
    
    boolean edit(Long id, Product product);
    
    boolean delete(Long id);

    /**
     *
     * @param id
     * @return
     */
    Product findById(Long id);
    
    public List<Product> findByName (String name);
    
    List<Product> findAll();

   /* public Product findByName(String Name);
    */

    public boolean saveCategory(Category nuevo);
}
